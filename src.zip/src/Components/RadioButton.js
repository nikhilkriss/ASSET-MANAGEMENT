import {Box, FormControl, FormLabel, FormControlLabel, RadioGroup, Radio} from '@mui/material';

const RadioButton =()=>{
    return(
        <Box>
            <FormControl>
                <FormLabel>
                    owned by proxima
                </FormLabel>
                
            </FormControl>
        </Box>
    );
}
export default RadioButton;