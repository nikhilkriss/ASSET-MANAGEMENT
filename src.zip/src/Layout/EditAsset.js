import React, { useState, useEffect } from "react";
import { Button, Stack } from "@mui/material";
import "../Assets/AddAsset.css";
import axios from "axios";
import { useForm, Controller } from "react-hook-form";
import { Box, TextField, Select } from "@mui/material";
import { FormControlLabel, Checkbox } from "@mui/material";
import Typography from "@mui/material/Typography";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { DatePicker } from "@mui/x-date-pickers";
import { format } from "date-fns";
import MenuItem from "@mui/material/MenuItem";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import Config from "../config";
import { FormControl, InputLabel } from "@mui/material";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogContentText,
  DialogActions,
} from "@mui/material";
const schema = yup.object().shape({
  ram: yup //only numbers and alphabets no spl char and atleast one number and one alphabet
    .string()
    .required("ram is required")
    .matches(/^(?=.*[0-9])(?=.*[a-zA-Z])(?!.*[^a-zA-Z0-9]).*$/),
  hdm: yup //only numbers and alphabets no spl char and atleast one number and one alphabet
    .string()
    .required("harddiskmemory is required")
    .matches(/^(?=.*[0-9])(?=.*[a-zA-Z])(?!.*[^a-zA-Z0-9]).*$/),
  osVersion: yup.string().matches(/^[a-zA-Z0-9.]+$/),
  processor: yup
    .string()
    .required("processor is required")
    .matches(/^[a-zA-Z0-9]+$/),
});
const EditAsset = ({ editingData, undoEdit }) => {
  console.log(editingData);
  // let defaultAsset=editingData.Asset;
  // let defaultBrand=editingData.Brand;
  let defaultModel=editingData.Model;
  // let defaultOS=editingData.OS;
  const {
    register,
    handleSubmit,
    reset,
    control,
    watch,
    formState: { errors },
    resetField,
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      category: editingData.Asset,
      brand: editingData.Brand,
      model: editingData.Model,
      // os:{defaultOS},
      serialNumber: "kytd",
    },
  });

  const [editDialog, setEditDialog] = useState(false);
  const [giveChance, setGiveChance] = useState(false);

  
  const putData = async (formData) => {
    try {
      const response = await axios.put(
        `https://jsonplaceholder.typicode.com/users/${editingData.id}`,
        formData
      );
      console.log(response);
      setEditDialog(true);
      // undoEdit();
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    if (editDialog) {
      setGiveChance(true);
    }
  }, [editDialog]);
  useEffect(() => {
    if (!editDialog && giveChance) {
      undoEdit();
    }
  }, [editDialog, giveChance]);
  const labelStyles = {
    fontSize: "0.86rem",
  };
  const checkLabelStyles = {
    fontSize: "0.875rem",
    fontWeight: 400,
    color: "rgba(0, 0, 0, 0.6)",
  };
  const handleFormSubmit = (formData) => {
    console.log(formData);
    console.log("success");
    reset();
    resetField("category");
    putData(formData);
  };
  const handleClear = () => {
    reset();
  };


  return (
    <div className="addAsset ">
      <div className="addAssetTitle">Edit Asset</div>
      {/*                                    basic */}

      <Dialog
        open={editDialog}
        onClose={() => {
          setEditDialog(false);
        }}
        aria-labelledby="dialog-title"
        aria-aria-describedby="dialog-description"
      >
        <DialogTitle id="dialog-title"></DialogTitle>
        <DialogContent>
          <DialogContentText id="dialog-description">
            Asset edited
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setEditDialog(false);
            }}
          >
            OK
          </Button>
        </DialogActions>
      </Dialog>
      <Box component="form" onSubmit={handleSubmit(handleFormSubmit)}>
        <div className="basic">
          <div className="basictitle">Basic</div>
          <div className="inputs">
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-around",
                marginBottom: "5px",
              }}
            >
              <Box>
              <TextField
                  fullWidth
                  disabled
                  label="Category"
                  {...register("category")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  variant="outlined"
                  required
                  size="small"
                  placeholder="Category..."
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
              <Box>
                {/* <Controller
                  name="brand"
                  defaultValue=""
                  control={control}
                  render={({ field }) => (
                    <FormControl fullWidth size="small" required disabled>
                      <InputLabel id="category-label">Brand</InputLabel>
                      <Select
                        {...field}
                        InputLabelProps={{
                          style: labelStyles,
                        }}
                        style={{ height: "30px", width: "180px" }}
                        label="Brand"
                        // ...other props for the Select component
                      >
                        <MenuItem value={defaultBrand}>
                        {defaultBrand}
                        </MenuItem>
                      </Select>
                    </FormControl>
                  )}
                /> */}
                <TextField
                  fullWidth
                  disabled
                  label="Brand"
                  {...register("brand")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  variant="outlined"
                  required
                  size="small"
                  placeholder="Brand..."
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-around",
                marginBottom: "5px",
              }}
            >
              <Box>
              <TextField
                  fullWidth
                  disabled
                  label="Model"
                  {...register("model")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  variant="outlined"
                  required
                  size="small"
                  placeholder="Model..."
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
              <Box>
                <Controller
                  name="os"
                  control={control}
                  // defaultValue=""
                  render={({ field }) => (
                    <FormControl fullWidth size="small" required disabled>
                      <InputLabel id="category-label">OS</InputLabel>
                      <Select
                        {...field}
                        // InputLabelProps={{
                        //   style: labelStyles,
                        // }}
                        style={{ height: "30px", width: "180px" }}

                        // ...other props for the Select component
                      >
                        {/* <MenuItem value={defaultOS}>
                        {defaultOS}
                        </MenuItem> */}
                      </Select>
                    </FormControl>
                  )}
                />
              </Box>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-around",
              }}
            >
              <Box>
                <TextField
                  fullWidth
                  label="OS Version"
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  variant="outlined"
                  size="small"
                  {...register("osVersion")}
                  placeholder={"OS Version..."}
                  error={!!errors.osVersion}
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
              <Box width="180px">
                <FormControlLabel
                  fullWidth
                  {...register("ownedByProxima")}
                  label={
                    <Typography variant="subtitle2" style={checkLabelStyles}>
                      Owned by Proxima
                    </Typography>
                  }
                  control={<Checkbox size="small" />}
                ></FormControlLabel>
              </Box>
            </div>
          </div>
        </div>
        {/*                                               details */}
        <div className="details">
          <div className="detailstitle">Details</div>
          <div className="inputs">
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                marginBottom: "5px",
                marginTop: "",
                justifyContent: "space-around",
              }}
            >
              <Box width="180px">
                <TextField
                  fullWidth
                  label="RAM(gb)"
                  {...register("ram", {
                    pattern: /^(?=.*[0-9])(?=.*[a-zA-Z])(?!.*[^a-zA-Z0-9]).*$/,
                  })}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  error={!!errors.ram}
                  variant="outlined"
                  required
                  size="small"
                  placeholder="RAM"
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
              <Box width="180px">
                <TextField
                  fullWidth
                  label="Hard Disk Memory(gb)"
                  {...register("hdm")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  variant="outlined"
                  required
                  error={!!errors.hdm}
                  size="small"
                  placeholder="Hard Disk Memory..."
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                marginBottom: "5px",
                justifyContent: "space-around",
              }}
            >
              <Box width="180px">
                <TextField
                  // value={text}
                  fullWidth
                  label="Processor"
                  {...register("processor")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  error={!!errors.processor}
                  variant="outlined"
                  required
                  size="small"
                  placeholder="Processor..."
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>

              <Box width="180px">
                <TextField
                  fullWidth
                  label="Serial Number"
                  {...register("serialNumber")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  error={!!errors.processor} //same as processor
                  variant="outlined"
                  required
                  size="small"
                  placeholder="Serial Number..."
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                marginBottom: "5px",
                justifyContent: "space-around",
              }}
            >
              <Controller
                name="purchaseDate"
                control={control}
                defaultValue={null}
                render={({ field }) => (
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      {...field}
                      label="Purchase Date"
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          InputLabelProps={{
                            style: labelStyles,
                          }}
                        />
                      )}
                      sx={{
                        "& .MuiInputBase-root": {
                          height: "30px",
                          width: "180px",
                          marginBottom: "0px",
                          marginTop: "5px",
                        },
                      }}
                      value={field.value ? new Date(field.value) : null}
                      onChange={(date) => {
                        field.onChange(
                          date ? format(date, "yyyy-MM-dd") : null
                        );
                      }}
                      InputLabelProps={{
                        style: labelStyles,
                      }}
                    />
                  </LocalizationProvider>
                )}
              />
              <Controller
                name="carePaqExpDate"
                control={control}
                defaultValue={null}
                render={({ field }) => (
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      {...field}
                      label="Care Paq Exp Date"
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          InputLabelProps={{
                            style: labelStyles,
                          }}
                        />
                      )}
                      sx={{
                        "& .MuiInputBase-root": {
                          height: "30px",
                          width: "180px",
                          marginBottom: "0px",
                          marginTop: "5px",
                          fontSize: "0.2rem",
                        },
                      }}
                      value={field.value ? new Date(field.value) : null}
                      onChange={(date) => {
                        field.onChange(
                          date ? format(date, "yyyy-MM-dd") : null
                        );
                      }}
                      InputLabelProps={{
                        style: labelStyles,
                      }}
                    />
                  </LocalizationProvider>
                )}
              />
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-around",
              }}
            >
              <Box width="180px">
                <TextField
                  label="Warranty Status"
                  {...register("warrantyStatus")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  select
                  fullWidth
                  size="small"
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                >
                  <MenuItem value="inWarranty">In Warranty</MenuItem>
                  <MenuItem value="expired">Expired</MenuItem>
                </TextField>
              </Box>
              <Box width="180px">
                <TextField
                  // value={text}
                  fullWidth
                  label="Display Dimensions"
                  {...register("displayDimensions")}
                  InputLabelProps={{
                    style: labelStyles,
                  }}
                  variant="outlined"
                  error={!!errors.processor} //same as processor
                  size="small"
                  placeholder="Display Dimensions"
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                      width: "180px",
                    },
                  }}
                />
              </Box>
            </div>
          </div>
        </div>
        <div className="buttons">
          <Stack spacing={2} direction="row">
            <Button variant="contained" size="small" onClick={handleClear}>
              Clear
            </Button>
            <Button variant="contained" type="submit" size="small">
              Edit Asset
            </Button>
          </Stack>
        </div>
      </Box>
    </div>
  );
};
export default EditAsset;
