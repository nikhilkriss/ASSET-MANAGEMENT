const config={
    ENVIRONMENT: "DEV",
    API_ENDPOINT: "http://52.89.223.51:5008/",
    API_ENDPOINT2: "http://52.89.223.51:80/",
};

export default config;