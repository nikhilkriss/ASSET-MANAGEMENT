const config={
    ENVIRONMENT: "DEV",
    API_ENDPOINT: "http://127.0.0.1:5007",
};
export default config